package carsProjectSem3.security.dto;

import lombok.Getter;
import lombok.Setter;

//public record LoginRequest(String userName, String password){
//
//}
//
@Getter
@Setter
public class LoginRequest{
   String username;
   String password;

}
