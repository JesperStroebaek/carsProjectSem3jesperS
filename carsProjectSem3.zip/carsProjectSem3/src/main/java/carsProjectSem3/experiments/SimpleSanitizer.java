package carsProjectSem3.experiments;



//Never use anything in here for real
public class SimpleSanitizer {

  public static String simpleSanitize(String s){


    throw new UnsupportedOperationException("Not implemented yet");
  }

}

